<form class="isint">
	<div class="form-group col-md-6">
		<label>Locale:</label>
		<input type="text" class="isint-locale form-control" name="my_element[validateOption][isint][locale]"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="isint-locale" name="my_element[validateOption][isint][locale]"/>
</div>