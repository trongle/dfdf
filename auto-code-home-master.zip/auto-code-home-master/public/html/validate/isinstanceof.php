<form class="isintanseof" >

	<div class="form-group col-md-6">
		<label>Class name:</label>
		<input type="text" class="isintanseof-classname form-control" name="my_element[validateOption][isintanseof][classname]" />
	</div> 

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="isintanseof-classname" name="my_element[validateOption][isintanseof][classname]"  />
</div>