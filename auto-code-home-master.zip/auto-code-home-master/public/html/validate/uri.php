<form class="uri">
	<div class="form-group col-md-12">
		allow relative :
		<input type="checkbox" class="uri-allowrelatie form-control" name="my_element[validateOption][uri][allowrelative]" />
	</div> 

	<div class="form-group col-md-12">
		allow absolute :
		<input type="checkbox" class="uri-allowabsolute" name="my_element[validateOption][uri][allowabsolute]" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="uri-allowrelatie" name="my_element[validateOption][uri][allowrelative]" />
	<input type="hidden" class="uri-allowabsolute" name="my_element[validateOption][uri][allowabsolute]" />
</div>