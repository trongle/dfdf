<form class="filesha1" >

	<div class="form-group col-md-6">
		<label>Hash:</label>
		<input type="text" class="filesha1-hash form-control" name="my_element[validateOption][filesha1][hash]"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="filesha1-hash" name="my_element[validateOption][filesha1][hash]" class="form-control"/>
</div>