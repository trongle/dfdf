<form class="fileexists" >

	<div class="form-group col-md-6">
		<label>direction:</label>
		<input type="text" class="fileexists-direction form-control" name="my_element[validateOption][fileexists][direction]"/>
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 

</form>
<div class="hidden-edit">
	<input type="hidden" class="fileexists-direction" name="my_element[validateOption][fileexists][direction]" class="form-control"/>
</div>