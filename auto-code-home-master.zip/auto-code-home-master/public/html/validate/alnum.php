<form class="alnum" >	
	<div class="form-group col-md-6">
		Allow white space:
		<input class="alnum-allowWhiteSpace" type="checkbox" name="my_element[validateOption][alnum][allowWhiteSpace]"   />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
<div class="hidden-edit">
	<div class="hide">
		<input class="alnum-allowWhiteSpace" type="checkbox" name="my_element[validateOption][alnum][allowWhiteSpace]"   />
	</div>
</div>
                            