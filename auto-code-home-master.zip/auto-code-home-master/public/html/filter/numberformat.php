<form class="numberformat">	

	<div class="form-group col-md-6">
		<label for="min">Locale:</label>
		<input type="text" class="numberformat-locale form-control" name="my_element[filterOption][numberformat][locale]" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Style:</label>
		<input type="text" class="numberformat-style form-control" name="my_element[filterOption][numberformat][style]" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Type:</label>
		<input type="text" class="numberformat-type form-control" name="my_element[filterOption][numberformat][type]" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>  
<div class="hidden-edit">
	<input type="hidden" class="numberformat-locale" name="my_element[filterOption][numberformat][locale]"  />
	<input type="hidden" class="numberformat-style" name="my_element[filterOption][numberformat][style]"  />
	<input type="hidden" class="numberformat-type" name="my_element[filterOption][numberformat][type]"  /> 
</div>
                            