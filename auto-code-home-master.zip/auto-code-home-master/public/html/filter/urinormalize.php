<form class="urinormalize">	

	<div class="form-group col-md-6">
		<label for="min">Default Scheme:</label>
		<input type="text" class="urinormalize-defaultScheme form-control" name="my_element[filterOption][urinormalize][defaultScheme]"  />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Enforced Scheme:</label>
		<input type="text" class="urinormalize-enforcedScheme form-control" name="my_element[filterOption][urinormalize][enforcedScheme]"  />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>  
<div class="hidden-edit">
	<input type="hidden" class="urinormalize-defaultScheme" name="my_element[filterOption][urinormalize][defaultScheme]"  class="form-control" />
	<input type="hidden" class="urinormalize-enforcedScheme" name="my_element[filterOption][urinormalize][enforcedScheme]"  class="form-control" /> 
</div>
                            