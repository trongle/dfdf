<form class="numberparse">	

	<div class="form-group col-md-6">
		<label for="min">Locale:</label>
		<input type="text" class="numberparse-locale form-control" name="my_element[filterOption][numberparse][locale]"  />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Style:</label>
		<input type="text" class="numberparse-style form-control" name="my_element[filterOption][numberparse][style]"  />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Type:</label>
		<input type="text" class="numberparse-type form-control" name="my_element[filterOption][numberparse][type]"  />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="numberparse-locale" name="my_element[filterOption][numberparse][locale]"  class="form-control" />
	<input type="hidden" class="numberparse-style" name="my_element[filterOption][numberparse][style]"  class="form-control" />
	<input type="hidden" class="numberparse-type" name="my_element[filterOption][numberparse][type]"  class="form-control" />  
</div>
                            