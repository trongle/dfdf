<form class="wordseparatortocamelcase">	

	<div class="form-group col-md-6">
		<label for="min">Separator:</label>
		<input type="text" class="wordseparatortocamelcase-separator form-control" name="my_element[filterOption][wordseparatortocamelcase][separator]" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="wordseparatortocamelcase-separator" name="my_element[filterOption][wordseparatortocamelcase][separator]" class="form-control" />   
</div>                            