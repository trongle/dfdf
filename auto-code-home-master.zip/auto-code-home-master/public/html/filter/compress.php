<form class="compress">	
	<div class="form-group col-md-6">
		<label for="min">Adapter:</label>
		<input type="text" class="compress-adapter form-control" name="my_element[filterOption][compress][adapter]"   />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Options:</label>
		<input type="text" class="compress-options form-control" name="my_element[filterOption][compress][options]" placeholder="i1:v1,i2:v2,i3:v3..."  />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
<div class="hidden-edit">
	<input type="hidden" class="compress-adapter" name="my_element[filterOption][compress][adapter]"   />
	<input type="hidden" class="compress-options" name="my_element[filterOption][compress][options]" placeholder="i1:v1,i2:v2,i3:v3..."  />
</div>
                            