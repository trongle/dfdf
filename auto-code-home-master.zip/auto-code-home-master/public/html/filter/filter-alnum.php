<form class="filter-alnum">	
	
	<div class="form-group col-md-6">
		<label for="adapter">Locale:</label>
		<input type="text" class="alnum-locale form-control" name="my_element[filterOption][alnum][locale]" />
	</div>

	<div class="form-group col-md-12">
		Allow white space: <input type="checkbox" class="alnum-allow_white_space" name="my_element[filterOption][alnum][allow_white_space]"   />
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
<div class="hidden-edit">
	<input type="hidden" class="alnum-locale" name="my_element[filterOption][alnum][locale]"/>
	<div class="hide">
		<input type="checkbox" class="alnum-allow_white_space" name="my_element[filterOption][alnum][allow_white_space]"   />
	</div>
</div>