<form class="wordunderscoretoseparator">	

	<div class="form-group col-md-6">
		<label for="min">Separator:</label>
		<input type="text" class="wordunderscoretoseparator-separator form-control" name="my_element[filterOption][wordunderscoretoseparator][separator]" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>  
<div class="hidden-edit">
	<input type="hidden" class="wordunderscoretoseparator-separator" name="my_element[filterOption][wordunderscoretoseparator][separator]" class="form-control" /> 
</div>
                            