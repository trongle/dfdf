<form class="stringtrim" >	

	<div class="form-group col-md-6">
		<label for="min">Charlist:</label>
		<input type="text" class="stringtrim-charlist form-control" name="my_element[filterOption][stringtrim][charlist]" placeholder="i1:v1,i2:v2....." />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form> 
<div class="hidden-edit">
	<input type="hidden" class="stringtrim-charlist" name="my_element[filterOption][stringtrim][charlist]" placeholder="i1:v1,i2:v2....." />  
</div>                            