<form class="htmlentities">	
	<div class="form-group col-md-6">
		<label for="min">Quotestyle:</label>
		<input type="text" class="htmlentities-quotestyle form-control" name="my_element[filterOption][htmlentities][quotestyle]"   />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Charset:</label>
		<input type="text" class="htmlentities-charset form-control" name="my_element[filterOption][htmlentities][charset]"  />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Double Quote:</label>
		<input type="text" class="htmlentities-doublequote form-control" name="my_element[filterOption][htmlentities][doublequote]"  />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form> 
<div class="hidden-edit">
	<input type="hidden" class="htmlentities-quotestyle" name="my_element[filterOption][htmlentities][quotestyle]"  class="form-control" />
	<input type="hidden" class="htmlentities-charset" name="my_element[filterOption][htmlentities][charset]" class="form-control" />
	<input type="hidden" class="htmlentities-doublequote" name="my_element[filterOption][htmlentities][doublequote]" class="form-control" />
</div>
                            