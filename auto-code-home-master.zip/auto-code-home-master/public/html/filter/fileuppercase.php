<form class="fileuppercase">	

	<div class="form-group col-md-6">
		<label for="min">Encoding:</label>
		<input type="text" class="fileuppercase-encoding form-control" name="my_element[filterOption][fileuppercase][encoding]"/>
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
<div class="hidden-edit">
	<input type="hidden" class="fileuppercase-encoding" name="my_element[filterOption][fileuppercase][encoding]" class="form-control" />
</div>