<form class="realpath">	

	<div class="form-group col-md-6">
		Exists:
		<input type="checkbox" class="realpath-exists" name="my_element[filterOption][realpath][exists]"/>
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
<div class="hidden-edit">
	<div class="hide">
		<input type="checkbox" class="realpath-exists" name="my_element[filterOption][realpath][exists]"/>
	</div>
</div>